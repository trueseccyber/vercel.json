/* Vercel Node.js Function: server-only authenticated Oxford Response request. */
export async function GET() {
  const key = process.env.OXFD_API_KEY;
  if (!key) {
    return Response.json({error: 'OXFD_API_KEY not configured'}, {status: 503});
  }
  try {
    const response = await fetch('https://api.oxfd.re/v1/server', {
      headers: { 'server-key': key },
      cache: 'no-store',
      signal: AbortSignal.timeout(9000)
    });
    if (!response.ok) {
      return Response.json({error: 'Oxford Response API returned ' + response.status}, {status: 502});
    }
    const data = await response.json();
    const online = String(data.Status ?? '').toLowerCase() === 'online';
    const players = Number(data.CurrentPlayers);
    const maxPlayers = Number(data.MaxPlayers);
    return Response.json({
      online,
      players: online && Number.isFinite(players) ? players : 0,
      maxPlayers: Number.isFinite(maxPlayers) ? maxPlayers : null
    }, {headers: {'Cache-Control': 'no-store'}});
  } catch (error) {
    return Response.json({error: 'Unable to fetch current server status'}, {status: 502});
  }
}

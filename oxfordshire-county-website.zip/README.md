# Oxfordshire County Roleplay – new website

This is a standalone replacement for the Canva homepage, created using the screenshots you provided. It does **not** fetch Canva at runtime and does **not** depend on `api/home.js`.

## Upload to a new GitHub repository

1. Create a **new empty** GitHub repository (e.g. `oxfordshire-county-website`).
2. Choose **Add file → Upload files** and upload the **contents** of this folder, keeping the `assets` and `api` directories. Don't upload the ZIP as just one file.
3. On Vercel, choose **Add New → Project**, import the new repository, use **Framework Preset: Other**, **Root Directory: `./`**, and deploy.
4. In Vercel → Project Settings → **Environment Variables**, add `OXFD_API_KEY` with your private Oxford Response server API key for Production. Then redeploy. Do not place the key in code or GitHub.
5. Test `/api/status` (returns JSON) and the homepage.

## Configure button destinations

Open `config.js` and add your actual links to `discordUrl`, `robloxGroupUrl`, and `developerUrl`. Those URLs could **not** be recovered reliably from the Canva site. Empty links display a message rather than opening the wrong server. The `playUrl` is the Roblox join URL previously supplied in the conversation; change it if your server join code changes.

The navigation's **Our Team** button opens `team.html`. Since no full team-page screenshot was provided, that page carries the under-development message instead of inventing members.

## Counter

The counter's black, rounded **ACTIVE / number** design follows the screenshot, is placed directly after the welcome panel, and scrolls normally. `/api/status` accesses the Oxford Response API using `server-key` on the server only. Refreshes every 30 seconds.

## Images

The hero and role cards use image crops from your screenshots, which preserves the look shown. The hero headline and role card labels are part of those screenshot crops rather than separate editable HTML text. Replace `/assets/*.webp` with the original image assets for sharper quality or fully editable captions. This version does not scrape or download originals from Canva.

## No old repo code

This project intentionally has no `api/home.js`, no external Canva rewrite, no iframe overlay, and no website visitor IP logging.

(function () {
  'use strict';
  const settings = window.OCR_CONFIG || {};
  const destinations = {
    discord: settings.discordUrl,
    group: settings.robloxGroupUrl,
    play: settings.playUrl,
    developer: settings.developerUrl
  };
  function showNotice(message) {
    let toast = document.getElementById('link-notice');
    if (!toast) {
      toast = document.createElement('div');
      toast.id = 'link-notice';
      toast.className = 'notice';
      toast.setAttribute('role', 'status');
      document.body.appendChild(toast);
    }
    toast.textContent = message;
    toast.hidden = false;
    window.clearTimeout(showNotice.timer);
    showNotice.timer = window.setTimeout(() => toast.hidden = true, 4000);
  }
  document.querySelectorAll('[data-link]').forEach((element) => {
    const type = element.getAttribute('data-link');
    const value = destinations[type];
    if (typeof value === 'string' && /^https:\/\//i.test(value)) {
      element.href = value;
      element.target = '_blank';
      element.rel = 'noopener noreferrer';
    } else {
      element.href = '#';
      element.addEventListener('click', (event) => {
        event.preventDefault();
        showNotice('Add the ' + type + ' URL in config.js to activate this button.');
      });
    }
  });
  const count = document.getElementById('player-count');
  if (!count) return;
  const status = document.getElementById('counter-status');
  const label = document.getElementById('counter-label');
  async function updateCount() {
    try {
      const response = await fetch('/api/status', {cache:'no-store'});
      if (!response.ok) throw new Error('API request returned ' + response.status);
      const data = await response.json();
      if (!Number.isFinite(Number(data.players))) throw new Error('Invalid player count');
      const online = data.online === true;
      count.textContent = online ? String(Number(data.players)) : '0';
      label.textContent = online ? 'ACTIVE' : 'OFFLINE';
      status.textContent = online ? 'Live server players' : 'Server currently offline';
    } catch (err) {
      count.textContent = '—';
      label.textContent = 'UNAVAILABLE';
      status.textContent = 'Could not load player count';
    }
  }
  updateCount();
  window.setInterval(updateCount, Math.max(10000, Number(settings.counterRefreshMs) || 30000));
})();

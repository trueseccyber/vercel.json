/* Change these links here. Empty values display a clear "link not configured" message. */
window.OCR_CONFIG = {
  discordUrl: "",
  robloxGroupUrl: "",
  // Previously provided Oxford Response private server join link:
  playUrl: "https://www.roblox.com/games/start?launchData=joinCode%3D7Z7TD&placeId=84910716336888",
  developerUrl: "",
  counterRefreshMs: 30000
};
